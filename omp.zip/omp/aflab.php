<html>
    
   
        
        <frameset cols="20%, 80%" >
        <frame src="alab.php" name="clist">
        <frame src="lab.php" name="cmain">
        </frameset>
       
    </frameset>
</html>
