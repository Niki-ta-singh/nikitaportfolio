<html>
    <body background="bg.jpg"></body>
</html>