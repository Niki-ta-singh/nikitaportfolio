    <body background="bg.jpg">
       <font face="Allura">
       
    <table>
        <tr><td align="center" width="500" heigth="250"><a href="test2.php"> <font size='17'>Logical Abilities</font></a> </td><td align="center" width="500" heigth="250"><a href="mathstest.php" target="_top"><font size='17'>Mathematics</font> </a></td></tr>
        <tr><td align="center" width="500" heigth="250"><a href="utseng.php"> <font size='17'>English</font></a> </td><td align="center" width="500" heigth="250"><a href="utsresn.php"><font size='17'>Reasoning </font></a></td></tr>
        <tr><td align="center" width="500" heigth="250"><a href="utsqap.php"> <font size='17'>Quantitive Aptitude</font></a> </td><td align="center" width="500" heigth="250"><a href="utscomp.php"><font size='17'>Computer</font></a></td></tr>
    </table>
       <a href="umain.php" target="main1"><input type="image" src='back.png' width="50" height="20" ></a>
</body>
