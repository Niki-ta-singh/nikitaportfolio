<html>
    
   
        
        <frameset cols="20%, 80%" >
        <frame src="aqap.php" name="clist">
        <frame src="qap.php" name="cmain">
        </frameset>
       
    </frameset>
</html>
