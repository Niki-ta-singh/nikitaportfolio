<html>
    
   
        
        <frameset cols="20%, 80%" >
        <frame src="ucomp.php" name="clist">
        <frame src="comp.php" name="cmain">
        </frameset>
       
    </frameset>
</html>
