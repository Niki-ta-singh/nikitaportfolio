<html>
    
    <body background="7.jpg">
        <font face="Allura" size="4">
        <ul>
            <li><a href="adminmain.php" target="main">Home</a><br></li>
            <li>User</li>
            <a href="auview.php" target="main">View</a><br>
            <a href="auview.php" target="main">Delete</a><br>
            <li>content</li>
            <a href="acadd.php" target="main">Add</a><br>
            <a href="acview.php" target="main">View</a><br>
            <a href="acdel.php" target="main">Delete</a><br>
            <li>Test Series</li>
            <a href="atsadd.php" target="main">Add</a><br>
            <a href="atsview.php" target="main">View</a><br>
            <a href="atsview.php" target="main">Delete</a><br>
            <li>Doubt Question/Answer</li>
            <a href="avdqa.php" target="main">View Doubt Question/Answer</a><br>
            <a href="avdqa.php" target="main">Delete Doubt Question/Answer</a><br>
            <li><a href="admincpass.php" target="main">Change Password</a></li>
            <li><a href="index.php" target="_top">logout</a></li>
           </ul>
        </font>
        
    </body>
    
   </html>