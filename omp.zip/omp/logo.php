<html>
    <head><title>top</title></head>
    <body background="8.jpg">
        <table width="100%" height="100%" >
            <tr><td widht="15%" height="100%"><img src="omp.png" hight="" width="200"></td><td width="85%" height="100%" align="left"><img src="title.png" hight="100%" width="100%"></td><td valign="top"> <a href="adminlogin.php" target="admin"><img src="adminlogo.png" width="50"  height="50"></a>
</td></tr>
        </table>  
    
        
    </body>
    
   </html>