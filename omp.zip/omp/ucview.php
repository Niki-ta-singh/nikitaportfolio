<body background="bg.jpg">
     <font face="Allura">
    <table>
        <tr><td align="center" width="500" heigth="250"><a href="uflab.php"><font size='17'>Logical Abilities</a> </td><td align="center" width="500" heigth="250"><a href="ufmath.php"><font size='17'>Mathematics</a></td></tr>
        <tr><td align="center" width="500" heigth="250"><a href="ufeng.php"><font size='17'> English</a> </td><td align="center" width="500" heigth="250"><a href="ufresn.php"><font size='17'>Reasoning </a></td></tr>
        <tr><td align="center" width="500" heigth="250"><a href="ufqap.php"><font size='17'> Quantitive Aptitude</a> </td><td align="center" width="500" heigth="250"><a href="ufcomp.php"><font size='17'>Computer</a></td></tr>
    </table><br><br><br><br><br>
    <a href="umain.php" target="main1"><input type="image" src='back.png' width="50" height="20" ></a>
</body>