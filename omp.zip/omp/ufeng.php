<html>
    
   
        
        <frameset cols="20%, 80%" >
        <frame src="ueng.php" name="clist">
        <frame src="eng.php" name="cmain">
        </frameset>
       
    </frameset>
</html>
