<body background="bg.jpg">
    <font face="Allura">
    <table>
        <tr><td align="center" width="500" heigth="250"><a href="aflab.php"><font size='20'> logical Abilities</a> </td><td align="center" width="500" heigth="250"><a href="afmath.php"><font size='20'>Mathematics</a></td></tr>
        <tr><td align="center" width="500" heigth="250"><a href="afeng.php"> <font size='20'>English</a> </td><td align="center" width="500" heigth="250"><a href="afresn.php"><font size='20'>Reasoning </a></td></tr>
        <tr><td align="center" width="500" heigth="250"><a href="afqap.php"><font size='20'> Quantitive Aptitude</a> </td><td align="center" width="500" heigth="250"><a href="afcomp.php"><font size='20'>Computer</a></td></tr>
    </table>
    <br><br><br><br><br><br><br>
    <input type="image" src='back.png' width="50" height="20" <a href="#" onclick="history.back();" value="back" id="back"></a>
</body>