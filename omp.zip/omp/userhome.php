
<html>
    
   
        <frameset rows="39%,7%,58%">
        <frame src="top.php" scrolling="no">
        <frame src="usearch.php" scrolling="no" >
            <frameset cols="80%, 20%">
        <frame src="umain.php" name="main1">
            <frameset rows="70%, 30%">
            <frame src="upostans.php" name="main2">
                <frame src="uaddques.php" name="main3" scrolling="no">
                    </frameset>
                
        </frameset>
       
    </frameset>
    
   
</html>
