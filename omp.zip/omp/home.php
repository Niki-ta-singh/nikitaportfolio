<html>

    <body background="bg.jpg">
<FONT face="Allura"> 
    <center><h1><u>Introduction</u><br/>
        </h1></center>

<p><font face="Comic Sans MS">Preparing for an entrance examination nowadays is very  costly and every student cannot afford. &ldquo;Online MCA Preparation&rdquo; is a website  that provides the students with all the detailed topic wise questions and  tricks to solve all the questions in less time duration. It provides regular  mock test that helps the student to know how much they can solve and in what  time. It also provides online lessons which help the student to first learn and  then test themselves. This website allows the student to gain knowledge outside  the class. This website will help the student to understand any particular  topic of the MCA entrance syllabus. The system consists of two modules one admin to govern the system and  user to access and use the system.</font></p>
<center> <h1><u>Objectives</u></h1></center>
        <ul><font face="Comic Sans MS"><li>This application provides resources  electronically that can be accessed by all the students preparing for MCA  entrance.</li>
            <li>It provides topic wise lessons and mock test by  which learning becomes easy.</li>
            <li>It provides study aid to the student just one  touch.</li>
            <li>It helps the students to understand any  particular topic of MCA entrance syllabus.</li>
            <li>It helps the students to gain knowledge outside  the class.</li>
            <li>To provide comfortable user interface.</li>
            </font></ul>
        </font>

    </body>

</html>