<html>
    
   
        
        <frameset cols="20%, 80%" >
        <frame src="aresn.php" name="clist">
        <frame src="resn.php" name="cmain">
        </frameset>
       
    </frameset>
</html>
