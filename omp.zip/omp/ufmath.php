<html>
    
   
        
        <frameset cols="20%, 80%" >
        <frame src="umaths.php" name="clist">
        <frame src="maths.php" name="cmain">
        </frameset>
       
    </frameset>
</html>
