<html>
    
   
        
        <frameset cols="20%, 80%" >
        <frame src="ulab.php" name="clist">
        <frame src="lab.php" name="cmain">
        </frameset>
       
    </frameset>
</html>
