
<html>
    
   
        <frameset rows="37%, 63%" border="0">
        <frame src="top.php" scrolling="no">
        <frameset cols="21%, 79%" border="0">
        <frame src="adminlist.php" name="list">
        <frame src="adminmain.php" name="main">
        </frameset>
       
    </frameset>
</html>
